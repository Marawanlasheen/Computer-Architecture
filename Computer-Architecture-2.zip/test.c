#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#define Inst_Mem_size 1024
#define Data_Mem_size 2048
#define Number_of_registers 64

// Opcodes
enum {
    ADD, SUB, MUL, MOVI, BEQZ, ANDI, EOR, BR, SAL, SAR, LDR, STR
};

// Function to get instruction name from opcode and operands
const char* get_instruction_string(uint16_t instruction) {
    static char instr_str[32]; 
    int8_t opcode = (instruction >> 12) & 0b1111;
    int8_t R1 = (instruction >> 6) & 0b111111;
    int8_t R2_Imm = instruction & 0b111111;
    

        if (R2_Imm & 0b00100000) { // Check if bit 5 (MSB of 6-bit immediate) is 1
        R2_Imm = R2_Imm | 0b11000000; // Sign extend to 8 bits
    } else {
        R2_Imm = R2_Imm;
    }
    
    const char* opcode_str;
    switch(opcode) {
        case ADD: opcode_str = "ADD"; break;
        case SUB: opcode_str = "SUB"; break;
        case MUL: opcode_str = "MUL"; break;
        case MOVI: opcode_str = "MOVI"; break;
        case BEQZ: opcode_str = "BEQZ"; break;
        case ANDI: opcode_str = "ANDI"; break;
        case EOR: opcode_str = "EOR"; break;
        case BR: opcode_str = "BR"; break;
        case SAL: opcode_str = "SAL"; break;
        case SAR: opcode_str = "SAR"; break;
        case LDR: opcode_str = "LDR"; break;
        case STR: opcode_str = "STR"; break;
        default: opcode_str = "UNKNOWN"; break;
    }
    
    switch(opcode) {
        case MOVI:
        case BEQZ:
        case ANDI:
        case SAL:
        case SAR:
        case LDR:
        case STR:
            snprintf(instr_str, sizeof(instr_str), "%s R%d %d", opcode_str, R1, R2_Imm);
            break;
        default:
            snprintf(instr_str, sizeof(instr_str), "%s R%d R%d", opcode_str, R1, R2_Imm);
            break;
    }
    return instr_str;
}
// Memory and registers
uint16_t instructionmemory[Inst_Mem_size];
int8_t datamemory[Data_Mem_size];
int8_t gen_registers[Number_of_registers];  // R0 to R63
uint16_t pc = 0;
int8_t sreg = 0;
int clock_cycle = 1;
int instruction_count = 0;
int br_taken = 0;  // New flag

// Pipeline stages
typedef struct {
    uint16_t instr;
    int valid;
    int pc_value;
} Stage;

Stage IF_stage = {0, 0, 0}, ID_stage = {0, 0, 0}, EX_stage = {0, 0, 0};

void clear_unused_sreg_bits() {
    sreg= sreg & 0b11111;
}
void update_zero_flag(int32_t result, int8_t opcode) {
    // Z: Zero flag - bit 0 (for ADD, SUB, MUL, ANDI, EOR, SAL, SAR)
    if (opcode == ADD || opcode == SUB || opcode == MUL || 
        opcode == ANDI || opcode == EOR || opcode == SAL || opcode == SAR) {
        if (result == 0) {
            sreg |= (1 << 0);  // Set Z flag if result is zero
        } else {
            sreg &= ~(1 << 0); // Clear Z flag if result is non-zero
        }
    }
}


void update_flags(int8_t op1, int8_t op2, int8_t result, int8_t opcode) {
    // C: Carry flag - bit 4 (only for ADD)
    if (opcode == ADD) {
        int16_t full_result = (int16_t)op1 + (int16_t)op2;
        if (full_result > 127 || full_result < -128) {
            sreg |= (1 << 4);  // Set carry
        } else {
            sreg &= ~(1 << 4); // Clear carry
        }
    }

    // V: Overflow flag - bit 3 (only for ADD and SUB)
    if (opcode == ADD || opcode == SUB) {
        if (opcode == ADD) {
            if (((op1 >= 0 && op2 >= 0) && result < 0) ||
                ((op1 < 0 && op2 < 0) && result >= 0)) {
                sreg |= (1 << 3);
            } else {
                sreg &= ~(1 << 3);
            }
        } else { // SUB
            if (((op1 >= 0 && op2 < 0) && result < 0) ||
                ((op1 < 0 && op2 >= 0) && result >= 0)) {
                sreg |= (1 << 3);
            } else {
                sreg &= ~(1 << 3);
            }
        }
    }

    // N: Negative flag - bit 2 (for ADD, SUB, MUL, ANDI, EOR, SAL, SAR)
    if (opcode == ADD || opcode == SUB || opcode == MUL || 
        opcode == ANDI || opcode == EOR || opcode == SAL || opcode == SAR) {
        if (result < 0) {
            sreg |= (1 << 2);
        } else {
            sreg &= ~(1 << 2);
        }
    }

    // S: Sign flag - bit 1 (only for ADD and SUB)
    if (opcode == ADD || opcode == SUB) {
        int8_t N = (sreg >> 2) & 1;
        int8_t V = (sreg >> 3) & 1;
        if (N ^ V) {
            sreg |= (1 << 1);
        } else {
            sreg &= ~(1 << 1);
        }
    }

    // Clear unused bits (bits 5, 6, 7)
    clear_unused_sreg_bits();
}

// In execute()
void execute(uint16_t instruction) {
    int8_t opcode = (instruction >> 12) & 0b1111;
    int8_t R1 = (instruction >> 6) & 0b111111;
    int8_t R2_Imm_val = instruction & 0b111111; // This is the 6-bit pattern

    int8_t imm_signed_6bit; // For 6-bit signed immediate
    int8_t imm_unsigned_6bit = R2_Imm_val; // For 6-bit unsigned immediate (SAL, SAR)

    // Sign-extend the 6-bit immediate R2_Imm_val to 8-bit signed
    if (R2_Imm_val & 0b00100000) { // Check if bit 5 (MSB of 6-bit immediate) is 1
        imm_signed_6bit = R2_Imm_val | 0b11000000; // Sign extend to 8 bits
    } else {
        imm_signed_6bit = R2_Imm_val;
    }

    int8_t op1, op2, result_val; // Use int8_t for signed arithmetic
    int8_t old_sreg = sreg;

    printf("    Debug - Instruction: 0x%04X, Opcode: %d, R1: %d, R2/Imm_pattern: %d (Signed: %d, Unsigned: %d)\n",
           instruction, opcode, R1, R2_Imm_val, imm_signed_6bit, imm_unsigned_6bit);

    switch (opcode) {
        case ADD:
            op1 = (int8_t)gen_registers[R1];
            op2 = (int8_t)gen_registers[R2_Imm_val & 0x3F];  // Use only the lower 6 bits for register number
            result_val = op1 + op2;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, op2, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case SUB:
            op1 = (int8_t)gen_registers[R1];
            op2 = (int8_t)gen_registers[R2_Imm_val];
            result_val = op1 - op2;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, op2, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case MUL:
            op1 = (int8_t)gen_registers[R1];
            op2 = (int8_t)gen_registers[R2_Imm_val];
            result_val = op1 * op2;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, op2, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case MOVI:
            if (R1 != 0) {
                gen_registers[R1] = imm_signed_6bit;
                printf("    -> Register R%d updated to %d in EX stage\n", R1, imm_signed_6bit);
            }
            // MOVI does NOT update SREG flags per package 3 spec
            break;
        case BEQZ:
            if (gen_registers[R1] == 0) {
                pc = EX_stage.pc_value + 1 + imm_signed_6bit;
                IF_stage.valid = ID_stage.valid = 0;
                printf("    -> BEQZ taken: PC updated to %d in EX stage\n", pc);
            }
            break;
        case ANDI:
            op1 = (int8_t)gen_registers[R1];
            result_val = op1 & imm_signed_6bit;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, imm_signed_6bit, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case EOR:
            op1 = (int8_t)gen_registers[R1];
            op2 = (int8_t)gen_registers[R2_Imm_val];
            result_val = op1 ^ op2;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, op2, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case BR:
            {
                int8_t val_r1 = gen_registers[R1];
                int8_t val_r2 = gen_registers[R2_Imm_val];
                pc = ((uint16_t)val_r1 << 8) | val_r2;
                IF_stage.valid = ID_stage.valid = 0;
                printf("    -> BR: PC updated to 0x%04X (R%d=0x%02X || R%d=0x%02X) in EX stage\n",
                       pc, R1, val_r1, R2_Imm_val, val_r2);
                break;
            }
        case SAL:
            op1 = (int8_t)gen_registers[R1];
            result_val = op1 << imm_unsigned_6bit;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, imm_unsigned_6bit, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case SAR:
            op1 = (int8_t)gen_registers[R1];
            result_val = op1 >> imm_unsigned_6bit;
            if (R1 != 0) {
                gen_registers[R1] = result_val;
                printf("    -> Register R%d updated to %d (signed) / %u (unsigned) in EX stage\n",
                       R1, (int8_t)result_val, (int8_t)result_val);
            }
            update_flags(op1, imm_unsigned_6bit, result_val, opcode);
            update_zero_flag(result_val, opcode);
            break;
        case LDR:
            if (R1 != 0) {
                gen_registers[R1] = datamemory[R2_Imm_val];
                printf("    -> Register R%d loaded value %d from memory[%d] in EX stage\n", R1, gen_registers[R1], R2_Imm_val);
            }
            break;
        case STR:
            datamemory[R2_Imm_val] = gen_registers[R1];
            printf("    -> Memory[%d] updated to %d in EX stage\n", R2_Imm_val, datamemory[R2_Imm_val]);
            break;
        default:
            printf("    Unknown opcode %d in EX stage\n", opcode);
            break;
    }

    if (sreg != old_sreg) {
        printf("    -> SREG updated to 0x%02X in EX stage\n", sreg);
    }
}

void step_pipeline() {
    printf("\nClock Cycle %d\n", clock_cycle++);

    // 🚩 FIRST fetch for IF stage BEFORE shifting
    if (pc < instruction_count) {
        IF_stage.instr = instructionmemory[pc];
        IF_stage.valid = 1;
        IF_stage.pc_value = pc;
        pc++;
    } else {
        IF_stage.valid = 0;
    }

    // Now print stages (current cycle's work)
    if (EX_stage.valid) {
        printf("  EX: Executing %s\n", get_instruction_string(EX_stage.instr));
        execute(EX_stage.instr);
    }
    if (ID_stage.valid) {
        printf("  ID: Decoding %s\n", get_instruction_string(ID_stage.instr));
    }
    if (IF_stage.valid) {
        printf("  IF: Fetched %s\n", get_instruction_string(IF_stage.instr));
    }

    // 🚩 THEN shift pipeline
    EX_stage = ID_stage;
    ID_stage = IF_stage;
}


void run_pipeline() {
    while (IF_stage.valid || ID_stage.valid || EX_stage.valid || pc < instruction_count) {
        step_pipeline();
    }
}

void print_final_state() {
    printf("\n==== Final Register File ====\n");
    for (int i = 0; i < 64; i++) {
        printf("R%-2d = %4d (signed) / %3u (unsigned)\n", i, (int8_t)gen_registers[i], gen_registers[i]);
    }

    printf("\n==== Final Data Memory (0–2047) ====\n");
    for (int i = 0; i < 2048; i++) {
        printf("M[%-4d] = %4d (signed) / %3u (unsigned)\n", i, (int8_t)datamemory[i], datamemory[i]);
    }

    printf("\nPC = %d\nSREG = 0x%02X\n", pc, sreg);
}


//read from the instruction file the instructions 
void read_instructions_from_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Error opening instruction file");
        exit(1);
    }
    char line[256];
    instruction_count = 0;
    while (fgets(line, sizeof(line), file)) {
        // Skip empty lines or comments
        if (line[0] == '\n' || line[0] == '#') continue;

        char opcode_str[10], operand1[10], operand2[10];
        int num_parsed = sscanf(line, "%s %s %s", opcode_str, operand1, operand2);

        if (num_parsed < 2) continue;  // Invalid line

        // Map opcode string to enum value
        int opcode = -1;
        if (strcmp(opcode_str, "ADD") == 0) opcode = ADD;
        else if (strcmp(opcode_str, "SUB") == 0) opcode = SUB;
        else if (strcmp(opcode_str, "MUL") == 0) opcode = MUL;
        else if (strcmp(opcode_str, "MOVI") == 0) opcode = MOVI;
        else if (strcmp(opcode_str, "BEQZ") == 0) opcode = BEQZ;
        else if (strcmp(opcode_str, "ANDI") == 0) opcode = ANDI;
        else if (strcmp(opcode_str, "EOR") == 0) opcode = EOR;
        else if (strcmp(opcode_str, "BR") == 0) opcode = BR;
        else if (strcmp(opcode_str, "SAL") == 0) opcode = SAL;
        else if (strcmp(opcode_str, "SAR") == 0) opcode = SAR;
        else if (strcmp(opcode_str, "LDR") == 0) opcode = LDR;
        else if (strcmp(opcode_str, "STR") == 0) opcode = STR;
        else {
            printf("Unknown opcode: %s\n", opcode_str);
            continue;
        }

        // Extract register numbers or immediate values
        int R1 = 0, R2_or_imm = 0;
        if (strncmp(operand1, "R", 1) == 0)
            R1 = atoi(operand1 + 1);
        if (num_parsed >= 3) {
            if (strncmp(operand2, "R", 1) == 0) {
                R2_or_imm = atoi(operand2 + 1);
            } else {
                // For immediate values, validate the range based on instruction type
                R2_or_imm = atoi(operand2);
                switch(opcode) {
                    case MOVI:
                    case BEQZ:
                    case ANDI:
                        // Signed immediate range check (-32 to 31)
                        if (R2_or_imm < -32 || R2_or_imm > 31) {
                            printf("Warning: Immediate value %d out of range for signed 6-bit field (-32 to 31). Value will be truncated.\n", R2_or_imm);
                        }
                        break;
                    case SAL:
                    case SAR:
                        // Unsigned immediate range check (0 to 63)
                        if (R2_or_imm < 0 || R2_or_imm > 63) {
                            printf("Warning: Immediate value %d out of range for unsigned 6-bit field (0 to 63). Value will be truncated.\n", R2_or_imm);
                        }
                        break;
                }
            }
        }

        // Build instruction
        uint16_t instr = (opcode << 12) | (R1 << 6) | (R2_or_imm & 0x3F);
        printf("Debug - Encoding: opcode=%d, R1=%d, R2/Imm=%d -> instruction=0x%04X\n",
               opcode, R1, R2_or_imm, instr);
        instructionmemory[instruction_count++] = instr;
    }
    fclose(file);
}

int main() {
    memset(gen_registers, 0, sizeof(gen_registers));
    memset(datamemory, 0, sizeof(datamemory));
    memset(instructionmemory, 0, sizeof(instructionmemory));

    read_instructions_from_file("test.txt");
    
    run_pipeline();
    print_final_state();
    return 0;
}
